# -*- coding: utf-8 -*-
"""
Created on Thu Nov 26 22:11:46 2020

@author: hp
"""
import sys

print('Number of arguments: {}'.format(len(sys.argv)))
print('Argument(s) passed: {}'.format(str(sys.argv)))

h = [1,2,3,4,5]

if (sys.argv[1] == 'update'):
    h.append(int(sys.argv[2]))
    print("Now the list is ", h)

if (sys.argv[1] == 'read'):
    print("The list is ", h)